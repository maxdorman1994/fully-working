// This file is kept for backward compatibility
// The actual homepage is now in Home.tsx
import Home from "./Home";

export default function Index() {
  return <Home />;
}
